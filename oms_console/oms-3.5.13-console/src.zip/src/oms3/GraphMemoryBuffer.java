/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oms3;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author Francesco Serafin
 */
public abstract class GraphMemoryBuffer {
    
    private static final ConcurrentHashMap<Integer, HashMap<String, FieldAccess>> MEMORYBUFFER = new ConcurrentHashMap<>();

    protected synchronized void add(Integer node, String varName, FieldAccess fa) {
        HashMap<String, FieldAccess> tmpHM = MEMORYBUFFER.get(node);
        if (tmpHM != null) {
            tmpHM.put(varName, fa);
            MEMORYBUFFER.replace(node, tmpHM);
        } else {
            tmpHM = new HashMap();
            tmpHM.put(varName, fa);
            MEMORYBUFFER.put(node, tmpHM);
        }
    }

    protected synchronized FieldAccess get(Integer from_node, String varName) {
        return MEMORYBUFFER.get(from_node).get(varName);
    }

}
