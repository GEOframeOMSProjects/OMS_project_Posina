/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oms3.ds.graph.traversers;

import java.util.ArrayDeque;
import java.util.Set;
import oms3.ds.graph.DiGraph;

/**
 *
 * @author sidereus
 */
abstract class SearchDirection {

	protected AlgorithmDS algoDS;
	protected ArrayDeque<Integer> path;

	abstract protected Set<Integer> getNeighbourhood(Integer vertex, DiGraph graph);
	abstract protected void allocatePath();
	abstract protected void addToPath(Integer vertex);

	protected Boolean isDone() {
		return algoDS.isEmpty();
	}

	protected Integer delete() {
		return algoDS.delete();
	}

	protected void add(Integer vertex) {
		algoDS.add(vertex);
	}
	
	protected Iterable<Integer> getPath() {
		return path;
	}

}
