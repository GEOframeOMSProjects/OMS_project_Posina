/*
 * $Id$
 * 
 * This file is part of the Object Modeling System (OMS),
 * 2007-2012, Olaf David and others, Colorado State University.
 *
 * OMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 2.1.
 *
 * OMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with OMS.  If not, see <http://www.gnu.org/licenses/lgpl.txt>.
 */
package oms3.dsl;

import groovy.lang.Closure;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.*;

import oms3.CLI;

/**
 * Core Simulation DSL
 *
 * @author od
 */
public class SimGraph extends AbstractSimulation {

    String alg = System.getProperty("oms3.digest.algorithm", "SHA-256");
    // The ontology
    Ontology ontology;
    List<Efficiency> eff = new ArrayList<Efficiency>();
    List<Summary> sum = new ArrayList<Summary>();
    File lastFolder;
    // Simulation resources.
    boolean digest = false;
    boolean sanitychecks = true;
    Closure pre;
    Closure post;
    private volatile Boolean empty;


    /**
     * perform sanity checks for the model, default is true.
     *
     * @param sanitychecks
     */
    public void setSanitychecks(boolean sanitychecks) {
        this.sanitychecks = sanitychecks;
    }


    public void setDigest(boolean digest) {
        this.digest = digest;
    }


    public void setPre(Closure pre) {
        this.pre = pre;
    }


    public void setPost(Closure post) {
        this.post = post;
    }


    @Override
    public Buildable create(Object name, Object value) {
        if (name.equals("ontology")) {
            return ontology = new Ontology();
        } else if (name.equals("efficiency")) {
            Efficiency e = new Efficiency();
            eff.add(e);
            return e;
        } else if (name.equals("summary")) {
            Summary e = new Summary();
            sum.add(e);
            return e;
//        } else if (name.equals("pre")) {
//            pre = (Closure) value;
//            return LEAF;
//        } else if (name.equals("post")) {
//            System.out.println("post here.");
//            post = (Closure) value;
//            System.out.println("post done.");
//            System.out.println(post);
//            return LEAF;
        }
        return super.create(name, value);
    }


    @Override
    public Object run() throws Exception {
        super.run();

        if (!sanitychecks) {
            System.setProperty("oms.skipCheck", "true");
        }

        if (log.isLoggable(Level.CONFIG)) {
            log.config("Run configuration ...");
        }

        if (digest) {
            String msg = "Digest not support for Graph simulation yet";
            throw new UnsupportedOperationException(msg);
        }

        // Path
        String libPath = null;//graph.getLibpath();
        if (libPath != null) {
            System.setProperty("jna.library.path", libPath);
            if (log.isLoggable(Level.CONFIG)) {
                log.config("Setting jna.library.path to " + libPath);
            }
        }

        Object comp = null;
        
        synchronized(this) {
            if (setpath == null) {
                setpath = graph.newModelComponent();
            }
        }
        
        int availProc = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(availProc);
        
        RunSimulations sim = new RunSimulations(setpath, executor, availProc);
        sim.run();
        executor.shutdown();

        return comp;
    }
    
    private class RunSimulations {
        
        private volatile ConcurrentLinkedDeque<Integer> path;
        private final CountDownLatch latch;
        private final ExecutorService executor;
        private final int concurrencyLevel;
        
        public RunSimulations(final ConcurrentLinkedDeque<Integer> path, final ExecutorService executor, final int availProc) {
            this.concurrencyLevel = availProc;
            this.executor = executor;
            this.path = new ConcurrentLinkedDeque<>(path);
            this.latch = new CountDownLatch(availProc);
        }
        
        public void run() throws InterruptedException {
            for (int i=0; i<concurrencyLevel; i++) {
                executor.submit(new ParallelSim(latch));
            }
            latch.await();
        }
        
        private Integer runSim() {
            
            Integer vertex = null;
            synchronized(this) {
                Iterator<Integer> iterator = setpath.iterator();
                while (iterator.hasNext()) {
                    vertex = iterator.next();
                    if (graph.readyForSim(vertex)) {
                        setpath.remove(vertex);
                        return vertex;
                    }
                }
            }
            return null;
        }
        
        private class ParallelSim implements Runnable {
            
            private final CountDownLatch latch;
            
            ParallelSim(CountDownLatch latch) { this.latch = latch; }
            
            @Override
            public void run() {
                empty = setpath.isEmpty();
                while (!empty) {
                    Integer index = runSim();
                    empty = setpath.isEmpty();
                    if (index != null) {
                        Object comp = null;
                        try {
                            comp = CLI.groovy("./simulation/" + index + ".sim", log.getLevel().toString());
                        } catch (Exception ex) {
                            String msg = "Loading sim file: ./simulation/" + index + ".sim";
                            Logger.getLogger(SimGraph.class.getName()).log(Level.SEVERE, msg, ex.getCause());
                            System.exit(1);
                        }
                        Sim tmpComp = (Sim) comp;
                        tmpComp.setNode(index);
                        tmpComp.setChildren(graph.getChildren(index));
                        try {
                            tmpComp.calibrationGraphParameters(graph.getParameter());
                        } catch (IOException ex) {
                            Logger.getLogger(SimGraph.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        try {
                            tmpComp.run();
                        } catch (Exception ex) {
                            String msg = "Running sim " + index + ".sim";
                            Logger.getLogger(SimGraph.class.getName()).log(Level.SEVERE, msg, ex.getCause());
                            System.exit(1);
                        }
                        graph.notify(index);
                    }
                }
                latch.countDown();
            }
        }
    }

}
